# OLX Dropship Parser

🔍 Парсит объявления с OLX по заданной категории, ключевикам и цене.

## 🚀 Использование

1. Открой `public/index.html` на GitHub Pages;
2. Заполни параметры и скачай `config.json`;
3. Помести его в `input/` директорию;
4. Запусти в Codex: `bash run_task.sh`;
5. Результат будет в `output/result.csv`.
