#!/bin/bash
pip install -r requirements.txt
python parser/olx_parser.py
